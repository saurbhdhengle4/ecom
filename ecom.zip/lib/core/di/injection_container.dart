import 'package:get_it/get_it.dart';

import '../../features/counter/data/datasources/counter_local_data_source.dart';
import '../../features/counter/data/repositories/counter_repository_impl.dart';
import '../../features/counter/domain/repositories/counter_repository.dart';
import '../../features/counter/domain/usecases/decrement_counter.dart';
import '../../features/counter/domain/usecases/get_count.dart';
import '../../features/counter/domain/usecases/increment_counter.dart';
import '../../features/counter/presentation/bloc/counter_bloc.dart';

final sl = GetIt.instance;

/// Registers every dependency for every feature. Call once from `main()`
/// before `runApp`. When adding a new feature, add its own `_init<Feature>`
/// function below and call it here.
Future<void> init() async {
  _initCounter();
}

void _initCounter() {
  // Presentation
  sl.registerFactory(
    () => CounterBloc(
      getCount: sl(),
      incrementCounter: sl(),
      decrementCounter: sl(),
    ),
  );

  // Domain
  sl.registerLazySingleton(() => GetCount(sl()));
  sl.registerLazySingleton(() => IncrementCounter(sl()));
  sl.registerLazySingleton(() => DecrementCounter(sl()));

  // Data
  sl.registerLazySingleton<CounterRepository>(
    () => CounterRepositoryImpl(sl()),
  );
  sl.registerLazySingleton<CounterLocalDataSource>(
    () => CounterLocalDataSourceImpl(),
  );
}
