class AppConstants {
  AppConstants._();

  static const String appName = 'Flutter Demo';
}
