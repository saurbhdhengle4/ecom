import 'package:flutter_bloc/flutter_bloc.dart';

import '../../../../core/usecase/usecase.dart';
import '../../domain/usecases/decrement_counter.dart';
import '../../domain/usecases/get_count.dart';
import '../../domain/usecases/increment_counter.dart';
import 'counter_event.dart';
import 'counter_state.dart';

class CounterBloc extends Bloc<CounterEvent, CounterState> {
  final GetCount getCount;
  final IncrementCounter incrementCounter;
  final DecrementCounter decrementCounter;

  CounterBloc({
    required this.getCount,
    required this.incrementCounter,
    required this.decrementCounter,
  }) : super(const CounterState()) {
    on<CounterStarted>(_onStarted);
    on<CounterIncremented>(_onIncremented);
    on<CounterDecremented>(_onDecremented);
  }

  Future<void> _onStarted(
    CounterStarted event,
    Emitter<CounterState> emit,
  ) async {
    emit(state.copyWith(status: CounterStatus.loading));
    final result = await getCount(const NoParams());
    result.fold(
      (failure) => emit(state.copyWith(
        status: CounterStatus.failure,
        errorMessage: failure.message,
      )),
      (count) => emit(state.copyWith(
        status: CounterStatus.success,
        count: count,
      )),
    );
  }

  Future<void> _onIncremented(
    CounterIncremented event,
    Emitter<CounterState> emit,
  ) async {
    final result = await incrementCounter(const NoParams());
    result.fold(
      (failure) => emit(state.copyWith(
        status: CounterStatus.failure,
        errorMessage: failure.message,
      )),
      (count) => emit(state.copyWith(
        status: CounterStatus.success,
        count: count,
      )),
    );
  }

  Future<void> _onDecremented(
    CounterDecremented event,
    Emitter<CounterState> emit,
  ) async {
    final result = await decrementCounter(const NoParams());
    result.fold(
      (failure) => emit(state.copyWith(
        status: CounterStatus.failure,
        errorMessage: failure.message,
      )),
      (count) => emit(state.copyWith(
        status: CounterStatus.success,
        count: count,
      )),
    );
  }
}
