import 'package:equatable/equatable.dart';

enum CounterStatus { initial, loading, success, failure }

class CounterState extends Equatable {
  final CounterStatus status;
  final int count;
  final String? errorMessage;

  const CounterState({
    this.status = CounterStatus.initial,
    this.count = 0,
    this.errorMessage,
  });

  CounterState copyWith({
    CounterStatus? status,
    int? count,
    String? errorMessage,
  }) {
    return CounterState(
      status: status ?? this.status,
      count: count ?? this.count,
      errorMessage: errorMessage,
    );
  }

  @override
  List<Object?> get props => [status, count, errorMessage];
}
