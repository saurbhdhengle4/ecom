import 'package:dartz/dartz.dart';

import '../../../../core/error/failures.dart';
import '../../../../core/usecase/usecase.dart';
import '../repositories/counter_repository.dart';

class IncrementCounter implements UseCase<int, NoParams> {
  final CounterRepository repository;

  const IncrementCounter(this.repository);

  @override
  Future<Either<Failure, int>> call(NoParams params) {
    return repository.increment();
  }
}
