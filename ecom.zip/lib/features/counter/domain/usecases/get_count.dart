import 'package:dartz/dartz.dart';

import '../../../../core/error/failures.dart';
import '../../../../core/usecase/usecase.dart';
import '../repositories/counter_repository.dart';

class GetCount implements UseCase<int, NoParams> {
  final CounterRepository repository;

  const GetCount(this.repository);

  @override
  Future<Either<Failure, int>> call(NoParams params) {
    return repository.getCount();
  }
}
