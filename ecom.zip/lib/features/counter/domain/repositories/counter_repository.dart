import 'package:dartz/dartz.dart';

import '../../../../core/error/failures.dart';

abstract class CounterRepository {
  Future<Either<Failure, int>> getCount();
  Future<Either<Failure, int>> increment();
  Future<Either<Failure, int>> decrement();
}
