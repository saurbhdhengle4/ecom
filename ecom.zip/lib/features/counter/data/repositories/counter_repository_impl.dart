import 'package:dartz/dartz.dart';

import '../../../../core/error/exceptions.dart';
import '../../../../core/error/failures.dart';
import '../../domain/repositories/counter_repository.dart';
import '../datasources/counter_local_data_source.dart';

class CounterRepositoryImpl implements CounterRepository {
  final CounterLocalDataSource localDataSource;

  const CounterRepositoryImpl(this.localDataSource);

  @override
  Future<Either<Failure, int>> getCount() => _guard(localDataSource.getCount);

  @override
  Future<Either<Failure, int>> increment() =>
      _guard(localDataSource.increment);

  @override
  Future<Either<Failure, int>> decrement() =>
      _guard(localDataSource.decrement);

  Future<Either<Failure, int>> _guard(Future<int> Function() action) async {
    try {
      return Right(await action());
    } on CacheException catch (e) {
      return Left(CacheFailure(e.message));
    }
  }
}
