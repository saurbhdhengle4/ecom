abstract class CounterLocalDataSource {
  Future<int> getCount();
  Future<int> increment();
  Future<int> decrement();
}

/// In-memory implementation. Swap this out for a SharedPreferences/SQLite
/// backed implementation later without touching the domain or presentation
/// layers.
class CounterLocalDataSourceImpl implements CounterLocalDataSource {
  int _count = 0;

  @override
  Future<int> getCount() async => _count;

  @override
  Future<int> increment() async => ++_count;

  @override
  Future<int> decrement() async => --_count;
}
